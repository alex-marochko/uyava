# Uyava Commercial License (Desktop Application)

Last updated: January 3, 2026

Uyava is licensed, not sold.

## Scope

This commercial license applies to the **Uyava Desktop Application** and any proprietary components distributed by the Author.

**This license does not apply to the Uyava DevTools Extension or any open-source components**
licensed under the **MIT License**.

## License Type

- **Per-developer** license
- Non-exclusive
- Non-transferable
- Commercial use allowed

## Restrictions

You may not:
- Share your paid plan access or license with others outside the licensed developer scope
- Redistribute or sell proprietary parts of the Software
- Circumvent, disable, or interfere with paid-feature activation or license checks

## Ownership

All rights, title, and interest in the proprietary parts of Uyava remain with the Author.

## Termination

This license terminates automatically if you breach its terms.