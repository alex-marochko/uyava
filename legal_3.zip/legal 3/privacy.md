# Uyava – Privacy Policy

Last updated: January 3, 2026

Uyava respects your privacy. This policy explains what data is collected and why.

## 1. Scope

This Privacy Policy applies to:
- the Uyava website (**uyava.io**) (the "Website")
- the Uyava DevTools Extension (open-source, MIT)
- the Uyava Desktop Application (the "Desktop App")

## 2. Data Collected by the DevTools Extension

The DevTools Extension runs locally in your development environment.
- It does not require an account.
- It does not send data to the Author by default.

If you choose to export, copy, or share logs/events/graphs, you control what you share and with whom.

## 3. Data Collected by the Desktop App

By default, the Desktop App is designed to work locally. We may collect **optional, anonymous** diagnostic information (telemetry) to ensure stability and improve the product.

**What we collect (if enabled):**
- Application version and platform information
- Feature usage statistics
- Performance and stability metrics
- Crash reports and error diagnostics

**What we do NOT collect:**
- Personal identifiers (name, email, account IDs)
- Source code or project content
- File system paths
- Keystrokes or clipboard data

## 4. User-Submitted Data

Uyava allows users to **manually** submit logs or diagnostic data.
You are solely responsible for the content you choose to submit.

## 5. Purpose of Data Use

Data is collected to:
- Improve usability and performance
- Identify bugs and crashes
- Prioritize feature development

## 6. Your Choices

Telemetry collection is optional. You can enable or disable the collection of anonymous usage data and crash reports at any time within the Desktop application settings.

## 7. Payments

Payments are processed by Paddle.
We do not collect or store payment information.

However, to manage subscriptions, license activation, and customer support, we may receive limited customer and transaction information from Paddle (such as your email address, order/invoice identifiers, subscription status, and billing country) and we may process the information you provide when you contact us for support. We do not receive or store full payment card details.

## 8. Data Sharing

We do not sell telemetry data and do not share it with third parties for advertising or profiling.

## 9. Contact

Legal inquiries: legal@uyava.io