# Uyava – Refund Policy

Last updated: January 3, 2026

Refunds for Uyava paid plans are handled by Paddle as the Merchant of Record.

## Refund Period

- Refund requests are accepted within **14 days** of purchase for all paid plans.
- After 14 days, purchases are non-refundable, except where required by applicable law.

## Subscriptions & Cancellation

- Subscription plans renew automatically until you cancel them.
- You can cancel at any time through Paddle; cancellation stops future renewals and you keep access until the end of the current billing period.
- We generally do not provide prorated refunds for partial billing periods, except where required by applicable law.
- Refund requests may be refused in cases of suspected fraud or abuse.


## Exceptions

Refunds may be granted outside this period in cases of verified technical incompatibility.

## How to Request a Refund

Refund requests should be submitted via Paddle's support system.

## Contact

Refund questions: legal@uyava.io