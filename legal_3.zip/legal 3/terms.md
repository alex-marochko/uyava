# Uyava – Terms of Service

Last updated: January 3, 2026

These Terms of Service ("Terms") govern your use of the Uyava software products,
including the Uyava website (uyava.io), the Uyava DevTools Extension, the Uyava Desktop Application, and related services ("Uyava", "the Software").

**Important:** The **Uyava DevTools Extension** is **fully open-source** and licensed under the **MIT License**.
These Terms primarily apply to the **Uyava Desktop Application** and any paid feature activation.

## 1. Who We Are

Uyava is operated by **Oleksandr Marochko**, an individual entrepreneur registered in Ukraine ("Author", "we"), under the brand name "Uyava".
Payments for paid plans are processed by Paddle.com as the Merchant of Record ("Paddle").

## 2. The Product

Uyava consists of:
- **Uyava DevTools Extension**: fully open-source (MIT License)
- **Uyava Desktop Application**: free to use, with optional paid features activated via a subscription or license

Some features available in the Desktop Application are not available in the DevTools Extension.

**Experimental & planned features:** Some features may be marked as *experimental*, may change without notice, or may be planned for future releases (for example: LLM-assisted analysis or embed mode). Do not rely on any feature being available unless it is included in the current released version.

## 3. Open-Source Software

The Uyava DevTools Extension and certain shared libraries/packages are distributed as open-source software under the **MIT License**.

- Open-source components are governed **exclusively** by the MIT License.
- These Terms do **not** replace or override the MIT License.

If there is a conflict between these Terms and the MIT License for a specific component,
the MIT License controls **for that component**.

## 4. Commercial License for the Desktop Application

For the Desktop Application (and any proprietary components), we grant you a limited, non-exclusive,
non-transferable, revocable, **per-developer** license to use Uyava for personal or commercial development purposes,
subject to these Terms and the applicable plan limitations.

You may not:
- Resell, sublicense, or distribute proprietary parts of Uyava
- Reverse engineer or decompile proprietary parts of the Software, except where permitted by law
- Circumvent or disable paid-feature activation or license checks

## 5. No Warranty

Uyava is provided "as is" and "as available", without warranties of any kind.
We do not guarantee that the Software will be error-free, uninterrupted, or fit for a particular purpose.

## 6. Limitation of Liability

To the maximum extent permitted by law, the Author shall not be liable for any indirect,
incidental, consequential, or special damages, including loss of data, profits, or business interruption.

## 7. Paid Features, Billing, and Who Sells What

Paid features in the Desktop Application are activated through Paddle.

- **Paddle is the Merchant of Record**: Paddle processes payments, taxes (including VAT/sales tax where applicable), and issues receipts/invoices.
- **The Author provides the software license and support**: your right to use Uyava is a license from the Author, and product support is provided by the Author.

## 8. Termination

We may suspend or terminate your commercial license for the Desktop Application if you violate these Terms.

## 9. Changes to These Terms

We may update these Terms from time to time.
If we make material changes, we will update the "Last updated" date at the top of this page.

## 10. Governing Law

These Terms shall be governed by and construed in accordance with the laws of Ukraine,
without regard to conflict of law principles.

## 11. Contact

Legal inquiries: legal@uyava.io